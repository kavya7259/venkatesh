# imdbClone
IMDB Clone made using the OMDB API

- Git Repository link: https://github.com/prabhatkumarmaharana/imdbClone-main.git
- Video link: 
- Hosted link: https://chipper-croissant-fc7a57.netlify.app/
